<?php

    $config->document_root = "";
    $config->path_root = "/home/bans/public_html";
    
    $config->db_host = "localhost";
    $config->db_user = "gamearmy_bans@gamearmy.pl";
    $config->db_pass = "BeeT5Ohqu1die3th";
    $config->db_db = "gamearmy_bans";
    $config->db_prefix = "amx";
    
?>
<?php
//language natives defined by amxmodx /data/lang/languages.txt
//used for motd

$amxx_langs["en"]="english";
$amxx_langs["de"]="german";
$amxx_langs["sr"]="serbian";
$amxx_langs["tr"]="turkish";
$amxx_langs["fr"]="french";
$amxx_langs["sv"]="swedish";
$amxx_langs["da"]="danish";
$amxx_langs["pl"]="polish";
$amxx_langs["nl"]="dutch";
$amxx_langs["es"]="spanish";
$amxx_langs["bp"]="brazilian portuguese";
$amxx_langs["pt_PT"]="portuguese";
$amxx_langs["cz"]="czech";
$amxx_langs["fi"]="finnish";
$amxx_langs["ls"]="l33t";
$amxx_langs["bg"]="bulgarian";
$amxx_langs["ro"]="romanian";
$amxx_langs["hu"]="hungarian";
$amxx_langs["lt"]="lithuania";
$amxx_langs["sk"]="slovak";
$amxx_langs["mk"]="macedonian";
$amxx_langs["ru"]="russian";
?>

# AMXBans for PHP 7

## Requirements

* PHP >= 7.0
* PHP extensions:
  * mysqli
  * gd
  * bcmath
  * xml
* MySQL >= 5.7 / MariaDB Server >= 10.3
* Apache >= 2.4

## Additional requirements

* SSL certificate on site